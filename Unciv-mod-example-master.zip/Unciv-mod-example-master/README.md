# Unciv-mod-example

An example mod for Unciv, that adds one new Civilization.

For information on how to build and use mods, please refer to [the setup instructions](https://yairm210.github.io/Unciv/Modders/Making-a-new-Civilization/)
